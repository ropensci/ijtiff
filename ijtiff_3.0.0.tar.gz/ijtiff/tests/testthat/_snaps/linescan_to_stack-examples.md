# `linescan_to_stack()` works

    The fourth dimension of `linescan_img` should be equal to 1 (or else it's not a linescan image).
    * Yours has `dim(linescan_img)[4] == 4`.

---

    The first dimension of `img` should be equal to 1 (or else it's not a stack that can be converted to a linescan).
    x Yours has dim(img)[1] == 4.

