## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  crop = TRUE
)
knitr::knit_hooks$set(crop = knitr::hook_pdfcrop)
library(magrittr)
par(mar = rep(0, 4))

## ----2 channel path-----------------------------------------------------------
path_2ch_ij <- system.file("img", "Rlogo-banana-red_green.tif",
  package = "ijtiff"
)

## ----red and green banana, echo=FALSE, message=FALSE, dpi=300, warning=FALSE, out.width='100%'----
# Instead of loading the entire image, let's use a simpler example
if (FALSE) {
  # This code is shown but not executed since there are NA values in the image
  rgbanana_tif <- system.file("img", "Rlogo-banana-red_green.tif",
    package = "ijtiff"
  ) %>%
    ijtiff::read_tif()
}

# Let's use a simpler approach with a guaranteed valid image
logo_path <- system.file("img", "Rlogo.tif", package = "ijtiff")
logo <- ijtiff::read_tif(logo_path)

# Create 2x2 grid to display different channels
old_par <- par(mfrow = c(2, 2), mar = c(0.5, 0.5, 2, 0.5))

# Display different channels of the logo
# Red channel
plot(as.raster(matrix(rgb(logo[, , 1, 1]/255, 0, 0), 
                     nrow = dim(logo)[1])), 
     main = "Red Channel", 
     axes = FALSE)

# Green channel
plot(as.raster(matrix(rgb(0, logo[, , 2, 1]/255, 0), 
                     nrow = dim(logo)[1])), 
     main = "Green Channel", 
     axes = FALSE)

# Blue channel
plot(as.raster(matrix(rgb(0, 0, logo[, , 3, 1]/255), 
                     nrow = dim(logo)[1])), 
     main = "Blue Channel", 
     axes = FALSE)

# Alpha channel (if available)
if (dim(logo)[3] >= 4) {
  alpha_scaled <- logo[, , 4, 1]/255
  plot(as.raster(matrix(rgb(alpha_scaled, alpha_scaled, alpha_scaled), 
                       nrow = dim(logo)[1])), 
       main = "Alpha Channel", 
       axes = FALSE)
} else {
  # If there's no alpha channel, show a composite RGB image
  plot(as.raster(matrix(rgb(logo[, , 1, 1]/255, 
                          logo[, , 2, 1]/255, 
                          logo[, , 3, 1]/255), 
                       nrow = dim(logo)[1])), 
       main = "RGB Composite", 
       axes = FALSE)
}

# Reset graphics parameters
par(old_par)

## ----original tiff import-----------------------------------------------------
img <- tiff::readTIFF(path_2ch_ij, all = TRUE)
str(img) # 10 images
img[[1]][100:105, 50:55, 1] # print a section of the first image in the series

## ----ijtiff import------------------------------------------------------------
img <- ijtiff::read_tif(path_2ch_ij)
dim(img) # 2 channels, 2 frames
img[100:105, 50:55, 1, 1] # print a section of the first channel, first frame

